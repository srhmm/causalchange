from __future__ import annotations

import time
from itertools import product
from typing import Any, Iterable

import networkx as nx
import pandas as pd
from pydantic import BaseModel, ValidationError

from benchmarks.synthetic.generators import (
    sample_single_continuous,
    sample_multi_continuous, sample_single_temporal, sample_multi_temporal,
)

from  benchmarks.synthetic.metrics import compute_metrics

from benchmarks.benchmark_configs import BenchmarkConfig, DataConfig, ScoringConfig, AlgoConfig, \
    LincAlgoConfig, TopicAlgoConfig, \
    SingleDataConfig, MultiDataConfig, MultiTemporalDataConfig, SingleTemporalDataConfig

from causalchange._cc_types import MixingType, ScoreType
from causalchange.causal_change import CausalChange
from causalchange.discovery._estimators import SpaceTime


def run_sampling(config: DataConfig):
    sampling_fun = sample_single_continuous if isinstance(config, SingleDataConfig) \
        else sample_multi_continuous if isinstance(config, MultiDataConfig) \
        else sample_single_temporal if isinstance(config, SingleTemporalDataConfig) \
        else sample_multi_temporal if isinstance(config, MultiDataConfig)  else None
    if sampling_fun is None:  raise RuntimeError(f"Unknown data config: {config!r}")

    df, true_g = sampling_fun(config)
    return df, true_g


def run_algo(df: pd.DataFrame, data_cfg: DataConfig, algo_cfg: AlgoConfig) -> Any:
    from causalchange._cc_types import DataMode, GraphSearch

    data_mode = DataMode(data_cfg.setting)
    graph_search = GraphSearch.TOPIC if algo_cfg.name in ("topic", "linc", "spacetime", "spacetime-c") else GraphSearch.TOPIC

    score_type = ScoreType (getattr(algo_cfg, "score_type", "gam"))
    tau_max = getattr(algo_cfg, "tau_max", 2)
    context_col = getattr(data_cfg, "context_col", "context")

    est = CausalChange(
        data_mode=data_mode,
        graph_search=graph_search,
        score_type=score_type,
        mixing_type=MixingType.SKIP,
        context_col=context_col,
        tau_max=tau_max,
        vb=0,
    )
    return est.fit(df)

def _pgmpy_graph_to_nx(dag: Any) -> nx.DiGraph:
    g = nx.DiGraph()
    g.add_nodes_from([str(n) for n in dag.nodes()])
    g.add_edges_from([(str(u), str(v)) for (u, v) in dag.edges()])
    return g

def run_scoring(true_g, est_dag, scoring_cfg: ScoringConfig) -> dict[str, float]:
    est_nx = _pgmpy_graph_to_nx(est_dag)
    m = compute_metrics(true_g, est_nx)

    out: dict[str, float] = {}
    if "shd" in scoring_cfg.metrics: out["shd"] = float(m.shd)
    if "edge_f1" in scoring_cfg.metrics: out["edge_f1"] = float(m.edge_f1)
    if "skel_f1" in scoring_cfg.metrics: out["skel_f1"] = float(m.skel_f1)

    return out


def run_on_config(cfg: BenchmarkConfig) -> dict[str, float]:
    df, true_g = run_sampling(cfg.data)

    t0 = time.perf_counter()
    est_dag = run_algo(df, cfg.data, cfg.algo)
    t1 = time.perf_counter()

    metrics = run_scoring(true_g, est_dag, cfg.scoring)
    if "time_s" in cfg.scoring.metrics:
        metrics["time_s"] = float(t1 - t0)

    return metrics



def _filter_to_model_fields(model_cls: type[BaseModel], data: dict[str, Any]) -> dict[str, Any]:
    allowed = set(model_cls.model_fields.keys())
    return {k: v for k, v in data.items() if k in allowed}


def _product_dict(d: dict[str, list[Any]]) -> Iterable[dict[str, Any]]:
    keys = list(d.keys())
    vals = [d[k] for k in keys]
    for combo in product(*vals):
        yield dict(zip(keys, combo))


def iter_valid_configs(grid: dict[str, Any]):
    data_grid = grid.get("data", {})
    algo_grid = grid.get("algo", {})
    scoring_grid = grid.get("scoring", {})

    scoring_options = list(_product_dict(scoring_grid)) if scoring_grid else [{}]

    for data_opt0 in _product_dict(data_grid):
        data_opt0 = dict(data_opt0)
        setting = data_opt0.get("setting")
        model = SingleDataConfig if setting == "single" else MultiDataConfig if setting == "multi" else \
            SingleTemporalDataConfig if setting == "time" else MultiTemporalDataConfig if setting == "time-contexts" else None
        if model is None: raise ValueError(setting)

        data_opt = _filter_to_model_fields(model, data_opt0)

        for algo in _product_dict(algo_grid):
            algo = dict(algo)  #?
            name = algo.get("name")

            algo_parent = _filter_to_model_fields(LincAlgoConfig, algo)if name in ["linc", "spacetime-c"] else \
                _filter_to_model_fields(TopicAlgoConfig, algo) if name in ["topic", "spacetime"] else None
            if algo_parent is None: raise ValueError(algo)

            for scoring_opt0 in scoring_options:
                scoring_opt = dict(scoring_opt0)
                candidate = {"data": data_opt, "algo": algo_parent, "scoring": scoring_opt}

                try:
                    yield BenchmarkConfig.model_validate(candidate)
                except ValidationError:
                    continue
